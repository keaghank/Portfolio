import java.util.HashMap;

/**
 * TODO: Complete the implementation of this class.
 */

public class FrequencyTable extends HashMap<Character, Integer> {
  /**
   * Constructs an empty table.
   */
  public FrequencyTable() {
    super();
  }
    
  /**
   * TODO: Make use of get() and put().
   * 
   * Constructs a table of character counts from the given text string.
   */
  public FrequencyTable(String text) {
    char[] countChar = text.toCharArray();
    for(Character c : countChar) {
      int count = get(c);
      if(count == 0)
        put(c, 1);
      put(c, count + 1);
    }
  }
  
  /**
   * TODO
   * 
   * Returns the count associated with the given character. In the case that
   * there is no association of ch in the map, return 0.
   */
  @Override
  public Integer get(Object ch) {
    if(containsKey(ch))
      return super.get(ch);
    return 0;
  }
}
